import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Kabinet";
import Pricing from "./components/BadanPengurusInti";
import Testimonials from "./components/Perasa";
import Footer from "./components/Footer";
import JadwalApelPage from "./components/JadwalApelPage";
import BeritaPage from "./components/BeritaPage";
import AppBackground from "./utils/AppBackground";

function App() {
  const [scrolled, setScrolled] = useState(false);
  const [page, setPage] = useState("home"); // home, berita, apel
  const [user, setUser] = useState(null); // null = belum login

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Logout cukup hapus user
  const logout = () => setUser(null);

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-hidden">
      <Navbar
        scrolled={scrolled}
        page={page}
        setPage={setPage}
        user={user}
        setUser={setUser} // Navbar bisa langsung update user saat login/logout
      />

      {/* Halaman Home */}
      {page === "home" && (
        <>
          <Hero />
          <Features />
          <AppBackground>
            <Pricing />
            <Testimonials />
          </AppBackground>
        </>
      )}

      {/* Halaman Berita */}
      {page === "berita" && <BeritaPage user={user} />}

      {/* Halaman Jadwal Apel */}
      {page === "apel" && <JadwalApelPage user={user} />}

      <Footer />
    </div>
  );
}

export default App;
