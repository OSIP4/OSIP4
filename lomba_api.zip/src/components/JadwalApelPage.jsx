import { useEffect, useState } from "react";
import axios from "axios";

export default function JadwalApelPage({ user }) {
  const [jadwal, setJadwal] = useState([]);
  const [form, setForm] = useState({ Hari: "", Tanggal: "", Kelas: "" });

  const API = "http://localhost/lomba_api/src/api/";

  // Load data jadwal
  useEffect(() => {
    axios
      .get(API + "get_jadwal.php")
      .then((res) => setJadwal(res.data))
      .catch((err) => console.error(err));
  }, []);

  const handleInput = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const tambahJadwal = (e) => {
    e.preventDefault();
    if (!user) {
      alert("Anda harus login untuk menambah jadwal!");
      return;
    }

    axios
      .post(API + "add_jadwal.php", form)
      .then((res) => {
        if (res.data.status === "success") {
          alert("Jadwal Ditambahkan!");
          window.location.reload();
        } else {
          alert(res.data.message || "Gagal menambah jadwal");
        }
      })
      .catch((err) => console.error(err));
  };

  const deleteJadwal = (id) => {
    if (!user) {
      alert("Anda harus login untuk menghapus jadwal!");
      return;
    }

    axios
      .post(API + "delete_jadwal.php", { id })
      .then((res) => {
        if (res.data.status === "success") {
          alert("Jadwal Dihapus!");
          window.location.reload();
        } else {
          alert(res.data.message || "Gagal menghapus jadwal");
        }
      })
      .catch((err) => console.error(err));
  };

  return (
    <div className="p-6 text-gray-800 dark:text-gray-200">
      <h2 className="text-2xl font-bold mb-4">📅 Jadwal Apel</h2>

      {/* FORM hanya tampil jika login */}
      {user && (
        <form onSubmit={tambahJadwal} className="bg-white dark:bg-gray-700 p-4 rounded shadow mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input
              type="text"
              name="Hari"
              placeholder="Hari"
              onChange={handleInput}
              className="p-2 rounded bg-gray-100 dark:bg-gray-800"
              required
            />
            <input
              type="date"
              name="Tanggal"
              onChange={handleInput}
              className="p-2 rounded bg-gray-100 dark:bg-gray-800"
              required
            />
            <input
              type="text"
              name="Kelas"
              placeholder="Kelas"
              onChange={handleInput}
              className="p-2 rounded bg-gray-100 dark:bg-gray-800"
              required
            />
          </div>
          <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Tambah
          </button>
        </form>
      )}

      {/* TABLE */}
      <table className="w-full text-left bg-white dark:bg-gray-700 rounded shadow">
        <thead>
          <tr className="bg-gray-200 dark:bg-gray-800">
            <th className="p-3">Hari</th>
            <th className="p-3">Tanggal</th>
            <th className="p-3">Kelas</th>
            {user && <th className="p-3">Aksi</th>}
          </tr>
        </thead>
        <tbody>
          {jadwal.map((row) => (
            <tr key={row.id_jadwal} className="border-t border-gray-300 dark:border-gray-600">
              <td className="p-3">{row.Hari}</td>
              <td className="p-3">{row.Tanggal}</td>
              <td className="p-3">{row.Kelas}</td>
              {user && (
                <td className="p-3">
                  <button
                    onClick={() => deleteJadwal(row.id_jadwal)}
                    className="px-3 py-1 bg-red-600 text-white rounded"
                  >
                    Hapus
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pesan jika tidak login */}
      {!user && <p className="mt-4 text-red-500">Login untuk menambah atau menghapus jadwal.</p>}
    </div>
  );
}
